<?php 
require_once 'classes/Conta.php'; 
require_once 'classes/ContaPoupanca.php'; 

class ContaPoupancaUniversitaria extends ContaPoupanca 
{ 
    // ... 
}