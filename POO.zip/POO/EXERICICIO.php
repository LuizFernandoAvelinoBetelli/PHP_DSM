<?php

class Pessoa{

    private $nome;
    private $idade;
    private $cpf;

    public function __construct($nome,$idade,$cpf){
        $this->nome = $nome;
        $this->idade = $idade;
        $this->cpf = $cpf;
    }

    public function getNome(){
        return $this->nome;
    }

    public function getIdade(){
        return $this->idade;
    }

    public function getCpf(){
        return $this->cpf;
    }
}


$p1 = new Pessoa('Luiz Fernando', 18 , 44724490802); 

print ' Nome: ' . $p1->getNome() . "<br>";
print ' Idade: ' . $p1->getIdade() . "<br> \n";
print ' Cpf : ' . $p1->getCpf() . "<br> \n";

class SalaVirtual{

    public  $aluno;
    public  $professor;

    public function __construct($aluno, $professor){
        $this->aluno = $aluno;
        $this->professor = $professor;
    }

    public function getAluno(){
        return $this->aluno;
    }

    public function getProfessor(){
        return $this->professor;
    }
}

$p2 = new SalaVirtual('Alberto', 'Cleiton');

echo '1º Sala ' . "<br> \n";

print ' Aluno: ' . $p2->getAluno() . "<br> \n";
print ' Professor: '. $p2->getProfessor(). "<br>";






?>