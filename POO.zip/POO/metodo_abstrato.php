<?php 
require_once 'classes/Conta.php'; 

class ContaSalario extends Conta 
{ 
    // ... 
} 