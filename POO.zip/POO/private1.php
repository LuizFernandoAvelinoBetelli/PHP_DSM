<?php 
class Pessoa 
{ 
    private $nome; 
    private $endereco; 
    private $nascimento; 
} 

$p1 = new Pessoa; 
$p1->nome = 'Maria da Silva'; 
$p1->endereco = 'Rua Bento Gonçalves'; 
$p1->nascimento = '01 de Maio de 2015'; 