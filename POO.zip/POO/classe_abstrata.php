<?php 
require_once 'classes/Conta.php'; 
$conta = new Conta;